package com.job;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobRecommenderSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobRecommenderSystemApplication.class, args);
	}

}
